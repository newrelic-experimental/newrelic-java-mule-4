package com.newrelic.mule.core4_4;

import com.newrelic.api.agent.HeaderType;
import com.newrelic.api.agent.Headers;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class NRMuleHeaders implements Headers {
  private HashMap<String, String> headers = new HashMap<>();
  
  public HeaderType getHeaderType() {
    return HeaderType.MESSAGE;
  }
  
  public String getHeader(String name) {
    return this.headers.get(name);
  }
  
  public Collection<String> getHeaders(String name) {
    String value = this.headers.get(name);
    List<String> list = new ArrayList<>();
    if (value != null)
      list.add(value); 
    return list;
  }
  
  public void setHeader(String name, String value) {
    this.headers.put(name, value);
  }
  
  public void addHeader(String name, String value) {
    this.headers.put(name, value);
  }
  
  public Collection<String> getHeaderNames() {
    return this.headers.keySet();
  }
  
  public boolean containsHeader(String name) {
    return this.headers.containsKey(name);
  }
  
  public boolean isEmpty() {
    return this.headers.isEmpty();
  }
  
  public void clear() {
    this.headers.clear();
  }
}
