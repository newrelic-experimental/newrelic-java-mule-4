package org.mule.runtime.core.internal.event;

import com.newrelic.api.agent.Headers;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.weaver.NewField;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core4_4.HeaderUtils;
import com.newrelic.mule.core4_4.NRMuleHeaders;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import org.mule.runtime.api.event.EventContext;
import org.mule.runtime.core.api.event.CoreEvent;
import org.mule.runtime.core.api.exception.FlowExceptionHandler;
import org.mule.runtime.core.privileged.event.BaseEventContext;
import org.reactivestreams.Publisher;

@Weave
abstract class AbstractEventContext implements BaseEventContext {
	
	@NewField
	public NRMuleHeaders headers = null;

	public AbstractEventContext() {}

	public AbstractEventContext(FlowExceptionHandler exceptionHandler, int depthLevel, Optional<CompletableFuture<Void>> externalCompletion) {
		if (this instanceof DefaultEventContext)
			setHeaders(); 
	}

	public abstract Optional<BaseEventContext> getParentContext();

	void addChildContext(BaseEventContext childContext) {
		if (childContext != null && childContext instanceof AbstractEventContext) {
			NRMuleHeaders childHeaders = MuleUtils.getHeaders((EventContext)childContext);
			if ((childHeaders == null || childHeaders.isEmpty()) && 
					this.headers != null && 
					this.headers.isEmpty()) {
				NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders((Headers)this.headers);
				if (!this.headers.isEmpty())
					MuleUtils.setHeaders((EventContext)childContext, this.headers); 
			} 
		} 
		Weaver.callOriginal();
	}

	public void success() {
		if (this.headers != null && !this.headers.isEmpty()) {
			HeaderUtils.acceptHeaders(this.headers, false);
			this.headers.clear();
			this.headers = null;
		} 
		try {
			Optional<BaseEventContext> parent = getParentContext();
			if (parent != null && parent.isPresent())
				expireParent(parent); 
		} catch (NullPointerException nullPointerException) {}
		Weaver.callOriginal();
	}

	private void expireParent(Optional<BaseEventContext> parent) {
		if (parent != null && parent.isPresent()) {
			BaseEventContext root = ((BaseEventContext)parent.get()).getRootContext();
			if (root instanceof AbstractEventContext) {
				((AbstractEventContext)root).headers.clear();
				((AbstractEventContext)root).headers = null;
			} 
		} 
	}

	public void success(CoreEvent event) {
		if (this.headers != null && !this.headers.isEmpty()) {
			HeaderUtils.acceptHeaders(this.headers, false);
			this.headers.clear();
			this.headers = null;
		} else {
			EventContext ctx = event.getContext();
			if (AbstractEventContext.class.isInstance(ctx)) {
				AbstractEventContext bctx = (AbstractEventContext)ctx;
				if (this.headers != null && !this.headers.isEmpty()) {
					HeaderUtils.acceptHeaders(this.headers, false);
					this.headers.clear();
					this.headers = null;
				} 
				try {
					Optional<BaseEventContext> parent = bctx.getParentContext();
					expireParent(parent);
				} catch (NullPointerException nullPointerException) {}
			} 
		} 
		try {
			Optional<BaseEventContext> parent = getParentContext();
			expireParent(parent);
		} catch (NullPointerException nullPointerException) {}
		Weaver.callOriginal();
	}

	public Publisher<Void> error(Throwable throwable) {
		if (this.headers != null && !this.headers.isEmpty()) {
			HeaderUtils.acceptHeaders(this.headers, false);
			this.headers.clear();
			this.headers = null;
		} 
		try {
			Optional<BaseEventContext> parent = getParentContext();
			expireParent(parent);
		} catch (NullPointerException nullPointerException) {}
		NewRelic.noticeError(throwable);
		return Weaver.callOriginal();
	}

	private void setHeaders() {
		if (this.headers == null) {
			this.headers = MuleUtils.getHeaders((EventContext)getRootContext());
			if (this.headers == null || this.headers.isEmpty())
				try {
					BaseEventContext root = getRootContext();
					if (root != null)
						MuleUtils.setHeaders((EventContext)root); 
				} catch (NullPointerException nullPointerException) {} 
		} 
	}
}
