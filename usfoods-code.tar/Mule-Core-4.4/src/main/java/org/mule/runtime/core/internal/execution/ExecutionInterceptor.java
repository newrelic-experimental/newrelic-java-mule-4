package org.mule.runtime.core.internal.execution;

import com.newrelic.agent.tracers.ClassMethodSignature;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core4_4.HeaderUtils;
import com.newrelic.mule.core4_4.tracers.TracerUtils;

import org.mule.runtime.core.api.execution.ExecutionCallback;

@Weave(type = MatchType.Interface)
public abstract class ExecutionInterceptor<T> {

	public T execute(ExecutionCallback<T> callback, ExecutionContext executionContext) {
		HeaderUtils.acceptHeaders(callback.headers, false);
		long start = System.nanoTime();
		T result = Weaver.callOriginal();
		long end = System.nanoTime();
		ClassMethodSignature sig = new ClassMethodSignature(getClass().getName(), "execute", TracerUtils.getMethodDesc(getClass(), "execute"));
		String[] names = { "Custom", "ExecutionInterceptor", getClass().getName(), "execute" };
		TracerUtils.processTracer(this, start, end, sig, null, names);
		return result;
	}
}
