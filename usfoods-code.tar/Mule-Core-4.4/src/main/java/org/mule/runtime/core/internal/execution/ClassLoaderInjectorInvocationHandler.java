package org.mule.runtime.core.internal.execution;

import com.newrelic.agent.tracers.ClassMethodSignature;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core4_4.tracers.TracerUtils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

@Weave
public abstract class ClassLoaderInjectorInvocationHandler {
	
	private final Object delegate = Weaver.callOriginal();

	public Object invoke(Object proxy, Method method, Object[] args) {
		List<String> names = new ArrayList<>();
		names.add("Custom");
		names.add("ClassLoaderInjectorInvocationHandler");
		if (proxy != null) {
			String tmp = proxy.getClass().getSimpleName();
			if (!tmp.startsWith("$"))
				names.add(proxy.getClass().getSimpleName()); 
		} 
		if (this.delegate != null) {
			String tmp = this.delegate.getClass().getSimpleName();
			if (!tmp.startsWith("$"))
				names.add(this.delegate.getClass().getSimpleName()); 
		} 
		if (method != null) {
			Class<?> declaring = method.getDeclaringClass();
			if (declaring != null)
				names.add(declaring.getSimpleName()); 
			String methodName = method.getName();
			names.add(methodName);
		} 
		String[] namesArray = new String[names.size()];
		names.toArray(namesArray);
		NewRelic.getAgent().getTracedMethod().setMetricName(namesArray);
		long start = System.nanoTime();
		Object result = Weaver.callOriginal();
		long end = System.nanoTime();
		ClassMethodSignature sig = new ClassMethodSignature(getClass().getName(), "invoke", TracerUtils.getMethodDesc(getClass(), "invoke"));
		TracerUtils.processTracer(this, start, end, sig, null, namesArray);
		return result;
	}
}
