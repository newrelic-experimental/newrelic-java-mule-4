package org.mule.runtime.core.internal.retry.async;

import com.newrelic.api.agent.Headers;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.NewField;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core4_3.HeaderUtils;
import com.newrelic.mule.core4_3.NRMuleHeaders;
import java.util.concurrent.Executor;
import org.mule.runtime.api.util.concurrent.Latch;
import org.mule.runtime.core.api.retry.RetryCallback;
import org.mule.runtime.core.api.retry.policy.RetryPolicyTemplate;

@Weave
public abstract class RetryWorker {
	
	@NewField
	private NRMuleHeaders headers = null;

	public RetryWorker(RetryPolicyTemplate delegate, RetryCallback callback, Executor workManager, Latch startLatch) {
		this.headers = new NRMuleHeaders();
		NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders((Headers)this.headers);
	}

	@Trace(dispatcher = true)
	public void run() {
		HeaderUtils.acceptHeaders(this.headers, false);
		Weaver.callOriginal();
	}
}
