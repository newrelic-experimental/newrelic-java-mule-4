package org.mule.runtime.core.internal.event;

import com.newrelic.api.agent.Headers;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.mule.core4_3.NRMuleHeaders;
import java.util.Optional;
import org.mule.runtime.api.event.EventContext;
import org.mule.runtime.core.api.event.CoreEvent;
import org.mule.runtime.core.privileged.event.BaseEventContext;

public class MuleUtils {
	
	public static NRMuleHeaders getHeaders(CoreEvent event) {
		EventContext context = event.getContext();
		if (context != null)
			return getHeaders(context); 
		return null;
	}

	public static NRMuleHeaders getHeaders(EventContext context) {
		if (AbstractEventContext.class.isInstance(context)) {
			AbstractEventContext tmpEventCtx = (AbstractEventContext)context;
			NRMuleHeaders headers = tmpEventCtx.headers;
			if (headers != null)
				return headers; 
			BaseEventContext rootContext = tmpEventCtx.getRootContext();
			if (rootContext != tmpEventCtx)
				return getHeaders((EventContext)rootContext); 
		} 
		return null;
	}

	public static void setHeaders(EventContext context) {
		if (context instanceof AbstractEventContext) {
			AbstractEventContext eventCtx = (AbstractEventContext)context;
			if (eventCtx.headers == null) {
				if (eventCtx instanceof DefaultEventContext) {
					eventCtx.headers = new NRMuleHeaders();
					NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders((Headers)eventCtx.headers);
					NewRelic.incrementCounter("MuleHeaders/insert/root");
				} else {
					Optional<BaseEventContext> parentOpt = ((AbstractEventContext)context).getParentContext();
					if (parentOpt.isPresent()) {
						AbstractEventContext p = (AbstractEventContext)parentOpt.get();
						eventCtx.headers = p.headers;
						NewRelic.incrementCounter("MuleHeaders/insert/child");
					} 
				} 
			} else if (eventCtx.headers.isEmpty()) {
				NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders((Headers)eventCtx.headers);
			} 
		} 
	}

	public static void setHeaders(EventContext context, NRMuleHeaders headers) {
		if (context instanceof BaseEventContext) {
			BaseEventContext rootContext = ((BaseEventContext)context).getRootContext();
			if (rootContext instanceof AbstractEventContext)
				((AbstractEventContext)rootContext).headers = headers; 
		} 
	}
}
