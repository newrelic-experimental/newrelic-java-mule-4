package org.mule.runtime.core.internal.processor;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TracedMethod;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core4_3.HeaderUtils;
import com.newrelic.mule.core4_3.NRCoreUtils;
import com.newrelic.mule.core4_3.NRMuleHeaders;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.mule.runtime.core.api.event.CoreEvent;
import org.mule.runtime.core.internal.event.MuleUtils;

@Weave
public abstract class InvokerMessageProcessor {
	
	protected Method method = (Method)Weaver.callOriginal();

	@Trace(dispatcher = true)
	public CoreEvent process(CoreEvent event) {
		Map<String, Object> attributes = new HashMap<>();
		NRCoreUtils.recordCoreEvent("Input", event, attributes);
		NRMuleHeaders headers = MuleUtils.getHeaders(event);
		HeaderUtils.acceptHeaders(headers, true);
		TracedMethod traced = NewRelic.getAgent().getTracedMethod();
		if (this.method != null) {
			traced.addCustomAttribute("Method-Class", this.method.getDeclaringClass().getName());
			traced.addCustomAttribute("Method-Name", this.method.getName());
			NewRelic.getAgent().getTracedMethod().setMetricName(new String[] { "Custom", "InvokerMessageProcessor", "process", this.method.getDeclaringClass().getName(), this.method.getName() });
		} 
		CoreEvent returnedEvent = (CoreEvent)Weaver.callOriginal();
		NRCoreUtils.recordCoreEvent("Returned", returnedEvent, attributes);
		traced.addCustomAttributes(attributes);
		return returnedEvent;
	}
}
