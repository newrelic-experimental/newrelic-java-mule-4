package org.mule.runtime.core.internal.event;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core4_3.NRMuleHeaders;
import org.mule.runtime.api.component.location.ComponentLocation;
import org.mule.runtime.api.event.EventContext;
import org.mule.runtime.core.api.event.CoreEvent;
import org.mule.runtime.core.internal.message.InternalEvent;
import org.mule.runtime.core.privileged.event.BaseEventContext;

@Weave
public abstract class DefaultEventBuilder {
	
	public InternalEvent build() {
		InternalEvent event = (InternalEvent)Weaver.callOriginal();
		String corrId = event.getCorrelationId();
		NewRelic.addCustomParameter("CorrelationId", corrId);
		BaseEventContext eventCtx = event.getContext();
		if (eventCtx != null) {
			NRMuleHeaders headers = MuleUtils.getHeaders((CoreEvent)event);
			if (headers == null || headers.isEmpty())
				MuleUtils.setHeaders((EventContext)eventCtx); 
			ComponentLocation location = eventCtx.getOriginatingLocation();
			if (location != null)
				NewRelic.addCustomParameter("Location", location.getLocation()); 
		} 
		return event;
	}
}
