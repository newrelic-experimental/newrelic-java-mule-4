package org.mule.runtime.core.internal.processor;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.mule.runtime.core.api.event.CoreEvent;
import org.mule.runtime.core.internal.event.MuleUtils;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core.HeaderUtils;
import com.newrelic.mule.core.NRCoreUtils;
import com.newrelic.mule.core.NRMuleHeaders;

@Weave
public abstract class InvokerMessageProcessor {

	protected Method method = Weaver.callOriginal();

	@Trace(async=true)
	public CoreEvent process(final CoreEvent event) {
		Map<String, Object> attributes = new HashMap<>();
		NRCoreUtils.recordCoreEvent("Input", event, attributes);
		if (this.method != null)
			NRCoreUtils.recordValue(attributes, "Method", this.method.getName()); 
		NRMuleHeaders headers = MuleUtils.getHeaders(event);
		HeaderUtils.acceptHeaders(headers, true);
		NewRelic.getAgent().getTracedMethod().setMetricName(new String[] { "Custom", "InvokerMessageProcessor", "process", this.method.getDeclaringClass().getName(), this.method.getName() });
		CoreEvent returnedEvent = (CoreEvent)Weaver.callOriginal();
		NRCoreUtils.recordCoreEvent("Returned", returnedEvent, attributes);
		NewRelic.getAgent().getTracedMethod().addCustomAttributes(attributes);
		return returnedEvent;
	}
}
