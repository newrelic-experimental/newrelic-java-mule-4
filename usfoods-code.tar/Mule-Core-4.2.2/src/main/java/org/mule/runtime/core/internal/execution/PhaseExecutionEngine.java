package org.mule.runtime.core.internal.execution;

import org.mule.runtime.api.component.location.ComponentLocation;
import org.mule.runtime.core.api.source.MessageSource;
import org.mule.runtime.core.privileged.execution.MessageProcessContext;
import org.mule.runtime.core.privileged.execution.MessageProcessTemplate;

import com.newrelic.api.agent.Headers;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TracedMethod;
import com.newrelic.api.agent.TransactionNamePriority;
import com.newrelic.api.agent.weaver.NewField;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.mule.core.HeaderUtils;
import com.newrelic.mule.core.NRMuleHeaders;

@Weave
public abstract class PhaseExecutionEngine {

	@Trace
	public void process(MessageProcessTemplate messageProcessTemplate, MessageProcessContext messageProcessContext) {
		String location = "Unknown";
		MessageSource source = messageProcessContext.getMessageSource();
		if(source != null) {
			ComponentLocation componentLoc = source.getLocation();
			if(componentLoc != null) {
				String temp = componentLoc.getLocation();
				if(temp != null && !temp.isEmpty()) {
					location = temp;
					if (location.endsWith("/source")) {
						location = location.replace("/source", "").trim(); 
					}
				}
			}
		}
		TracedMethod traced = NewRelic.getAgent().getTracedMethod();
		if(!location.equals("Unknown")) {
			NewRelic.getAgent().getTransaction().setTransactionName(TransactionNamePriority.CUSTOM_LOW, false, "Flow", new String[] { location });
			traced.addCustomAttribute("Location", location);
		}
		traced.setMetricName("Custom","PhaseExecutionEngine","process",location);
		Weaver.callOriginal();
	}

	@Weave
	public static class InternalPhaseExecutionEngine {

		private final MessageProcessContext messageProcessContext = (MessageProcessContext)Weaver.callOriginal();

		@NewField
		private String name;

		@NewField
		private NRMuleHeaders headers;

		public InternalPhaseExecutionEngine(MessageProcessTemplate messageProcessTemplate, MessageProcessContext messageProcessContext) {
			this.name = null;
			this.headers = null;
		}

		@Trace
		public void process() {
			if (this.messageProcessContext != null) {
				MessageSource source = this.messageProcessContext.getMessageSource();
				if (source != null) {
					ComponentLocation location = source.getLocation();
					if (location != null) {
						String tmp = location.getLocation();
						if (tmp != null && !tmp.isEmpty()) {
							this.headers = new NRMuleHeaders();
							NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders((Headers)this.headers);
							this.name = "Phase-" + tmp;
						} 
					} 
				} 
			} 
			Weaver.callOriginal();
		}

		@Trace(dispatcher = true)
		private void processEndPhase() {
			HeaderUtils.acceptHeaders(this.headers, true);
			if (this.name != null) {
				NewRelic.getAgent().getTracedMethod().setMetricName(new String[] { "Custom", "PhaseExecution", "EndPhase", this.name }); 
			}
			Weaver.callOriginal();
		}
	}

}
