package com.newrelic.mule.core;

import com.newrelic.agent.bridge.AgentBridge;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import java.util.function.BiConsumer;

public class NRBiConsumer<T, U> implements BiConsumer<T, U> {
  private String name = null;
  
  private NRMuleHeaders headers = null;
  
  private static boolean isTransformed = false;
  
  public NRBiConsumer(String n) {
    this.name = n;
    this.headers = new NRMuleHeaders();
    NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders(this.headers);
    if (!isTransformed) {
      AgentBridge.instrumentation.retransformUninstrumentedClass(getClass());
      isTransformed = true;
    } 
  }
  
  @Trace(dispatcher = true)
  public void accept(T t, U u) {
	  
    if (this.name != null && !this.name.isEmpty()) {
    	NewRelic.getAgent().getTracedMethod().setMetricName(new String[] { "Custom", "CompletionHandler", this.name }); 
    }
    HeaderUtils.acceptHeaders(this.headers, false);
    
  }
}
