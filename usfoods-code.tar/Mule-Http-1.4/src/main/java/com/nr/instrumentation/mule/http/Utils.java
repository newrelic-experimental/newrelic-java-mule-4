package com.nr.instrumentation.mule.http;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mule.runtime.http.api.server.HttpServer;
import org.mule.runtime.http.api.server.RequestHandler;
import org.mule.runtime.http.api.utils.RequestMatcherRegistry;
import org.mule.service.http.impl.service.server.ServerAddressMap;

public class Utils {

	
	public static String getPath(Object obj) {
		String path = null;
		
		Class<?> clazz = obj.getClass();
		
		
		
		return path;
	}
}
