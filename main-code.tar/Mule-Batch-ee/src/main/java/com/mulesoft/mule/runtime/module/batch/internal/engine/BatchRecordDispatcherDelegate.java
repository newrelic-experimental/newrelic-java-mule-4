package com.mulesoft.mule.runtime.module.batch.internal.engine;

public abstract class BatchRecordDispatcherDelegate {

}
